const express = require('express');
const router = express.Router();
const {
  createTask,
  getTasks,
  getTaskById,
  updateTask,
  deleteTask,
  restoreTask,
  getDashboardStats,
} = require('../controllers/taskController');
const { protect } = require('../middleware/auth');
const {
  validate,
  taskValidationRules,
  taskUpdateValidationRules,
  taskQueryValidationRules,
} = require('../middleware/validators');

router.use(protect); // every route below requires authentication

// Note: specific routes must come before the '/:id' routes
router.get('/stats/dashboard', getDashboardStats);

router.post('/', taskValidationRules, validate, createTask);
router.get('/', taskQueryValidationRules, validate, getTasks);
router.get('/:id', getTaskById);
router.put('/:id', taskUpdateValidationRules, validate, updateTask);
router.delete('/:id', deleteTask);
router.put('/:id/restore', restoreTask);

module.exports = router;
