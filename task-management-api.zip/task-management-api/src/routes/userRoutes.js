const express = require('express');
const router = express.Router();
const {
  getProfile,
  updateProfile,
  changePassword,
  uploadAvatar,
  getActivityLog,
} = require('../controllers/userController');
const { protect } = require('../middleware/auth');
const upload = require('../middleware/upload');
const {
  validate,
  changePasswordValidationRules,
  updateProfileValidationRules,
} = require('../middleware/validators');

router.use(protect); // every route below requires authentication

router.get('/profile', getProfile);
router.put('/profile', updateProfileValidationRules, validate, updateProfile);
router.put('/change-password', changePasswordValidationRules, validate, changePassword);
router.post('/profile/avatar', upload.single('avatar'), uploadAvatar);
router.get('/activity', getActivityLog);

module.exports = router;
