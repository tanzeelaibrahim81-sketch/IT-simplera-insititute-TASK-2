const express = require('express');
const router = express.Router();
const { register, login, logout, refreshAccessToken } = require('../controllers/authController');
const { protect } = require('../middleware/auth');
const {
  validate,
  registerValidationRules,
  loginValidationRules,
} = require('../middleware/validators');
const { authLimiter } = require('../middleware/rateLimiter');

router.post('/register', authLimiter, registerValidationRules, validate, register);
router.post('/login', authLimiter, loginValidationRules, validate, login);
router.post('/logout', protect, logout);
router.post('/refresh-token', refreshAccessToken);

module.exports = router;
