const User = require('../models/User');
const asyncHandler = require('../middleware/asyncHandler');
const { AppError } = require('../middleware/errorHandler');
const fs = require('fs');
const path = require('path');

// @route   GET /api/users/profile
// @access  Private
const getProfile = asyncHandler(async (req, res) => {
  res.status(200).json({ success: true, data: { user: req.user } });
});

// @route   PUT /api/users/profile
// @access  Private
const updateProfile = asyncHandler(async (req, res, next) => {
  const { name, email } = req.body;

  if (email && email !== req.user.email) {
    const existing = await User.findOne({ email });
    if (existing) {
      return next(new AppError('That email is already in use', 409));
    }
  }

  if (name) req.user.name = name;
  if (email) req.user.email = email;

  req.user.logActivity('profile_updated', 'Profile details updated');
  await req.user.save();

  res.status(200).json({ success: true, message: 'Profile updated', data: { user: req.user } });
});

// @route   PUT /api/users/change-password
// @access  Private
const changePassword = asyncHandler(async (req, res, next) => {
  const { currentPassword, newPassword } = req.body;

  const user = await User.findById(req.user.id).select('+password');
  const isMatch = await user.comparePassword(currentPassword);
  if (!isMatch) {
    return next(new AppError('Current password is incorrect', 401));
  }

  user.password = newPassword;
  user.refreshTokens = []; // force re-login on all devices after password change
  user.logActivity('password_changed', 'Password was changed');
  await user.save();

  res.status(200).json({ success: true, message: 'Password changed successfully. Please log in again.' });
});

// @route   POST /api/users/profile/avatar
// @access  Private
// Advanced feature: Profile Picture Upload
const uploadAvatar = asyncHandler(async (req, res, next) => {
  if (!req.file) {
    return next(new AppError('No image file provided', 400));
  }

  // Remove old avatar file if it exists
  if (req.user.avatar) {
    const oldPath = path.join(__dirname, '..', req.user.avatar);
    fs.unlink(oldPath, () => {}); // best-effort cleanup, ignore errors
  }

  req.user.avatar = `/uploads/avatars/${req.file.filename}`;
  req.user.logActivity('avatar_updated', 'Profile picture updated');
  await req.user.save();

  res.status(200).json({
    success: true,
    message: 'Avatar uploaded successfully',
    data: { user: req.user },
  });
});

// @route   GET /api/users/activity
// @access  Private
// Advanced feature: Recent Activity Log
const getActivityLog = asyncHandler(async (req, res) => {
  const limit = Math.min(parseInt(req.query.limit, 10) || 20, 50);
  res.status(200).json({
    success: true,
    data: { activity: req.user.activityLog.slice(0, limit) },
  });
});

module.exports = { getProfile, updateProfile, changePassword, uploadAvatar, getActivityLog };
