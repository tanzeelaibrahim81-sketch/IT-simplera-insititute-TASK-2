const Task = require('../models/Task');
const asyncHandler = require('../middleware/asyncHandler');
const { AppError } = require('../middleware/errorHandler');

// @route   POST /api/tasks
// @access  Private
const createTask = asyncHandler(async (req, res) => {
  const { title, description, priority, status, dueDate } = req.body;

  const task = await Task.create({
    user: req.user.id,
    title,
    description,
    priority,
    status,
    dueDate,
  });

  req.user.logActivity('task_created', `Created task "${task.title}"`);
  await req.user.save();

  res.status(201).json({ success: true, message: 'Task created', data: { task } });
});

// @route   GET /api/tasks
// @access  Private
// Advanced features: Search, Filter by Status, Filter by Priority,
// Pagination, Sorting — all combined in one flexible endpoint.
// Query params:
//   ?search=keyword
//   ?status=pending|in-progress|completed
//   ?priority=low|medium|high
//   ?page=1&limit=10
//   ?sortBy=createdAt|dueDate|priority|title|status&order=asc|desc
//   ?includeDeleted=true (defaults to false, i.e. soft-deleted tasks hidden)
const getTasks = asyncHandler(async (req, res) => {
  const {
    search,
    status,
    priority,
    page = 1,
    limit = 10,
    sortBy = 'createdAt',
    order = 'desc',
    includeDeleted = 'false',
  } = req.query;

  const query = { user: req.user.id };

  if (includeDeleted !== 'true') {
    query.isDeleted = false;
  }
  if (status) query.status = status;
  if (priority) query.priority = priority;
  if (search) {
    // Simple case-insensitive search across title & description
    query.$or = [
      { title: { $regex: search, $options: 'i' } },
      { description: { $regex: search, $options: 'i' } },
    ];
  }

  const pageNum = Math.max(parseInt(page, 10) || 1, 1);
  const limitNum = Math.min(Math.max(parseInt(limit, 10) || 10, 1), 100);
  const skip = (pageNum - 1) * limitNum;

  const sortOrder = order === 'asc' ? 1 : -1;
  const sortObj = { [sortBy]: sortOrder };

  const [tasks, total] = await Promise.all([
    Task.find(query).sort(sortObj).skip(skip).limit(limitNum),
    Task.countDocuments(query),
  ]);

  res.status(200).json({
    success: true,
    data: {
      tasks,
      pagination: {
        total,
        page: pageNum,
        limit: limitNum,
        totalPages: Math.ceil(total / limitNum) || 1,
        hasNextPage: pageNum * limitNum < total,
        hasPrevPage: pageNum > 1,
      },
    },
  });
});

// @route   GET /api/tasks/:id
// @access  Private
const getTaskById = asyncHandler(async (req, res, next) => {
  const task = await Task.findOne({ _id: req.params.id, user: req.user.id });
  if (!task) {
    return next(new AppError('Task not found', 404));
  }
  res.status(200).json({ success: true, data: { task } });
});

// @route   PUT /api/tasks/:id
// @access  Private
const updateTask = asyncHandler(async (req, res, next) => {
  const task = await Task.findOne({ _id: req.params.id, user: req.user.id });
  if (!task) {
    return next(new AppError('Task not found', 404));
  }

  const allowedFields = ['title', 'description', 'priority', 'status', 'dueDate'];
  allowedFields.forEach((field) => {
    if (req.body[field] !== undefined) {
      task[field] = req.body[field];
    }
  });

  await task.save();

  req.user.logActivity('task_updated', `Updated task "${task.title}"`);
  await req.user.save();

  res.status(200).json({ success: true, message: 'Task updated', data: { task } });
});

// @route   DELETE /api/tasks/:id
// @access  Private
// Advanced feature: Soft Delete (task is flagged, not removed from DB).
// Pass ?hard=true to permanently delete instead.
const deleteTask = asyncHandler(async (req, res, next) => {
  const task = await Task.findOne({ _id: req.params.id, user: req.user.id });
  if (!task) {
    return next(new AppError('Task not found', 404));
  }

  if (req.query.hard === 'true') {
    await task.deleteOne();
    req.user.logActivity('task_deleted_permanently', `Permanently deleted task "${task.title}"`);
  } else {
    task.isDeleted = true;
    task.deletedAt = new Date();
    await task.save();
    req.user.logActivity('task_deleted', `Soft-deleted task "${task.title}"`);
  }

  await req.user.save();

  res.status(200).json({ success: true, message: 'Task deleted' });
});

// @route   PUT /api/tasks/:id/restore
// @access  Private
// Companion endpoint to soft delete, lets a user undo a delete.
const restoreTask = asyncHandler(async (req, res, next) => {
  const task = await Task.findOne({ _id: req.params.id, user: req.user.id, isDeleted: true });
  if (!task) {
    return next(new AppError('Deleted task not found', 404));
  }

  task.isDeleted = false;
  task.deletedAt = null;
  await task.save();

  res.status(200).json({ success: true, message: 'Task restored', data: { task } });
});

// @route   GET /api/tasks/stats/dashboard
// @access  Private
// Advanced features: Dashboard Statistics + Task Completion Percentage
const getDashboardStats = asyncHandler(async (req, res) => {
  const userId = req.user._id;

  const [statusCounts, priorityCounts, totalActive, overdueCount] = await Promise.all([
    Task.aggregate([
      { $match: { user: userId, isDeleted: false } },
      { $group: { _id: '$status', count: { $sum: 1 } } },
    ]),
    Task.aggregate([
      { $match: { user: userId, isDeleted: false } },
      { $group: { _id: '$priority', count: { $sum: 1 } } },
    ]),
    Task.countDocuments({ user: userId, isDeleted: false }),
    Task.countDocuments({
      user: userId,
      isDeleted: false,
      status: { $ne: 'completed' },
      dueDate: { $lt: new Date(), $ne: null },
    }),
  ]);

  const statusMap = { pending: 0, 'in-progress': 0, completed: 0 };
  statusCounts.forEach((s) => {
    statusMap[s._id] = s.count;
  });

  const priorityMap = { low: 0, medium: 0, high: 0 };
  priorityCounts.forEach((p) => {
    priorityMap[p._id] = p.count;
  });

  const completionPercentage =
    totalActive > 0 ? Math.round((statusMap.completed / totalActive) * 100) : 0;

  res.status(200).json({
    success: true,
    data: {
      totalTasks: totalActive,
      byStatus: statusMap,
      byPriority: priorityMap,
      completionPercentage,
      overdueTasks: overdueCount,
    },
  });
});

module.exports = {
  createTask,
  getTasks,
  getTaskById,
  updateTask,
  deleteTask,
  restoreTask,
  getDashboardStats,
};
