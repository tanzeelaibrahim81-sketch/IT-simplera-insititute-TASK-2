const jwt = require('jsonwebtoken');
const User = require('../models/User');
const asyncHandler = require('../middleware/asyncHandler');
const { AppError } = require('../middleware/errorHandler');
const { generateAccessToken, generateRefreshToken } = require('../utils/generateToken');

const REFRESH_COOKIE_OPTIONS = {
  httpOnly: true,
  secure: process.env.NODE_ENV === 'production',
  sameSite: 'strict',
  maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
};

// @route   POST /api/auth/register
// @access  Public
const register = asyncHandler(async (req, res, next) => {
  const { name, email, password } = req.body;

  const existingUser = await User.findOne({ email });
  if (existingUser) {
    return next(new AppError('An account with that email already exists', 409));
  }

  const user = await User.create({ name, email, password });
  user.logActivity('account_created', 'User registered');
  await user.save();

  const accessToken = generateAccessToken(user._id);
  const refreshToken = generateRefreshToken(user._id);

  user.refreshTokens.push({ token: refreshToken });
  await user.save();

  res.cookie('refreshToken', refreshToken, REFRESH_COOKIE_OPTIONS);
  res.status(201).json({
    success: true,
    message: 'User registered successfully',
    data: { user, accessToken },
  });
});

// @route   POST /api/auth/login
// @access  Public
const login = asyncHandler(async (req, res, next) => {
  const { email, password } = req.body;

  const user = await User.findOne({ email }).select('+password');
  if (!user || !(await user.comparePassword(password))) {
    return next(new AppError('Invalid email or password', 401));
  }
  if (!user.isActive) {
    return next(new AppError('This account has been deactivated', 401));
  }

  const accessToken = generateAccessToken(user._id);
  const refreshToken = generateRefreshToken(user._id);

  user.refreshTokens.push({ token: refreshToken });
  user.logActivity('login', 'User logged in');
  await user.save();

  res.cookie('refreshToken', refreshToken, REFRESH_COOKIE_OPTIONS);
  res.status(200).json({
    success: true,
    message: 'Login successful',
    data: { user, accessToken },
  });
});

// @route   POST /api/auth/logout
// @access  Private
const logout = asyncHandler(async (req, res, next) => {
  const refreshToken = req.cookies?.refreshToken || req.body.refreshToken;

  if (refreshToken && req.user) {
    req.user.refreshTokens = req.user.refreshTokens.filter(
      (rt) => rt.token !== refreshToken
    );
    req.user.logActivity('logout', 'User logged out');
    await req.user.save();
  }

  res.clearCookie('refreshToken', REFRESH_COOKIE_OPTIONS);
  res.status(200).json({ success: true, message: 'Logged out successfully' });
});

// @route   POST /api/auth/refresh-token
// @access  Public (requires valid refresh token cookie)
const refreshAccessToken = asyncHandler(async (req, res, next) => {
  const refreshToken = req.cookies?.refreshToken || req.body.refreshToken;
  if (!refreshToken) {
    return next(new AppError('No refresh token provided', 401));
  }

  let decoded;
  try {
    decoded = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET);
  } catch (err) {
    return next(new AppError('Invalid or expired refresh token, please log in again', 401));
  }

  const user = await User.findById(decoded.id);
  const tokenExists = user?.refreshTokens.some((rt) => rt.token === refreshToken);
  if (!user || !tokenExists) {
    return next(new AppError('Refresh token not recognized, please log in again', 401));
  }

  const newAccessToken = generateAccessToken(user._id);
  res.status(200).json({ success: true, data: { accessToken: newAccessToken } });
});

module.exports = { register, login, logout, refreshAccessToken };
