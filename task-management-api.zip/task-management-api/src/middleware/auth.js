const jwt = require('jsonwebtoken');
const User = require('../models/User');
const asyncHandler = require('./asyncHandler');
const { AppError } = require('./errorHandler');

/**
 * Protect routes: verifies the JWT access token sent in the
 * Authorization header ("Bearer <token>") and attaches the
 * authenticated user to req.user.
 */
const protect = asyncHandler(async (req, res, next) => {
  let token;

  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    token = authHeader.split(' ')[1];
  }

  if (!token) {
    return next(new AppError('Not authorized, no token provided', 401));
  }

  let decoded;
  try {
    decoded = jwt.verify(token, process.env.JWT_SECRET);
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return next(new AppError('Access token expired, please refresh', 401));
    }
    return next(new AppError('Not authorized, invalid token', 401));
  }

  const user = await User.findById(decoded.id);
  if (!user) {
    return next(new AppError('The user belonging to this token no longer exists', 401));
  }
  if (!user.isActive) {
    return next(new AppError('This account has been deactivated', 401));
  }

  req.user = user;
  next();
});

module.exports = { protect };
