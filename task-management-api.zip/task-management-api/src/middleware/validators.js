const { body, query, validationResult } = require('express-validator');
const { AppError } = require('./errorHandler');

// Runs after the *ValidationRules arrays below and turns any collected
// validation errors into a single 400 AppError with a readable message.
const validate = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    const message = errors
      .array()
      .map((e) => e.msg)
      .join('. ');
    return next(new AppError(message, 400));
  }
  next();
};

const registerValidationRules = [
  body('name').trim().isLength({ min: 2, max: 50 }).withMessage('Name must be 2-50 characters'),
  body('email').trim().isEmail().withMessage('A valid email is required').normalizeEmail(),
  body('password')
    .isLength({ min: 8 })
    .withMessage('Password must be at least 8 characters')
    .matches(/\d/)
    .withMessage('Password must contain at least one number'),
];

const loginValidationRules = [
  body('email').trim().isEmail().withMessage('A valid email is required').normalizeEmail(),
  body('password').notEmpty().withMessage('Password is required'),
];

const changePasswordValidationRules = [
  body('currentPassword').notEmpty().withMessage('Current password is required'),
  body('newPassword')
    .isLength({ min: 8 })
    .withMessage('New password must be at least 8 characters')
    .matches(/\d/)
    .withMessage('New password must contain at least one number'),
];

const updateProfileValidationRules = [
  body('name').optional().trim().isLength({ min: 2, max: 50 }).withMessage('Name must be 2-50 characters'),
  body('email').optional().trim().isEmail().withMessage('A valid email is required').normalizeEmail(),
];

const taskValidationRules = [
  body('title').trim().notEmpty().withMessage('Title is required').isLength({ max: 150 }),
  body('description').optional({ checkFalsy: true }).trim().isLength({ max: 2000 }),
  body('priority').optional().isIn(['low', 'medium', 'high']).withMessage('Priority must be low, medium, or high'),
  body('status')
    .optional()
    .isIn(['pending', 'in-progress', 'completed'])
    .withMessage('Status must be pending, in-progress, or completed'),
  body('dueDate').optional({ checkFalsy: true }).isISO8601().withMessage('Due date must be a valid date'),
];

const taskUpdateValidationRules = [
  body('title').optional().trim().notEmpty().withMessage('Title cannot be empty').isLength({ max: 150 }),
  body('description').optional({ checkFalsy: true }).trim().isLength({ max: 2000 }),
  body('priority').optional().isIn(['low', 'medium', 'high']).withMessage('Priority must be low, medium, or high'),
  body('status')
    .optional()
    .isIn(['pending', 'in-progress', 'completed'])
    .withMessage('Status must be pending, in-progress, or completed'),
  body('dueDate').optional({ checkFalsy: true }).isISO8601().withMessage('Due date must be a valid date'),
];

const taskQueryValidationRules = [
  query('page').optional().isInt({ min: 1 }).withMessage('page must be a positive integer'),
  query('limit').optional().isInt({ min: 1, max: 100 }).withMessage('limit must be between 1 and 100'),
  query('status').optional().isIn(['pending', 'in-progress', 'completed']),
  query('priority').optional().isIn(['low', 'medium', 'high']),
  query('sortBy').optional().isIn(['createdAt', 'dueDate', 'priority', 'title', 'status']),
  query('order').optional().isIn(['asc', 'desc']),
];

module.exports = {
  validate,
  registerValidationRules,
  loginValidationRules,
  changePasswordValidationRules,
  updateProfileValidationRules,
  taskValidationRules,
  taskUpdateValidationRules,
  taskQueryValidationRules,
};
