// Wraps an async route/middleware function and forwards any
// rejected promise (thrown error) to Express's error handler,
// so we don't need try/catch in every controller.
const asyncHandler = (fn) => (req, res, next) => {
  Promise.resolve(fn(req, res, next)).catch(next);
};

module.exports = asyncHandler;
