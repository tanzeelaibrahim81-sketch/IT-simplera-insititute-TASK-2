/**
 * Simple seed script — creates one demo user with a handful of tasks so you
 * can explore the API / dashboard stats right away.
 *
 * Usage: npm run seed
 */
require('dotenv').config();
const connectDB = require('../config/db');
const User = require('../models/User');
const Task = require('../models/Task');
const mongoose = require('mongoose');

const run = async () => {
  await connectDB();

  await User.deleteMany({ email: 'demo@example.com' });

  const user = await User.create({
    name: 'Demo User',
    email: 'demo@example.com',
    password: 'password123',
  });

  const tasks = [
    { title: 'Set up project repository', priority: 'high', status: 'completed', dueDate: '2026-06-01' },
    { title: 'Design database schema', priority: 'high', status: 'completed', dueDate: '2026-06-03' },
    { title: 'Implement authentication', priority: 'high', status: 'in-progress', dueDate: '2026-07-15' },
    { title: 'Build task CRUD endpoints', priority: 'medium', status: 'in-progress', dueDate: '2026-07-20' },
    { title: 'Write API documentation', priority: 'medium', status: 'pending', dueDate: '2026-07-25' },
    { title: 'Record demo video', priority: 'low', status: 'pending', dueDate: '2026-07-28' },
    { title: 'Deploy to production', priority: 'high', status: 'pending', dueDate: '2026-08-01' },
  ];

  await Task.insertMany(tasks.map((t) => ({ ...t, user: user._id })));

  console.log('Seed complete.');
  console.log('Demo login -> email: demo@example.com | password: password123');

  await mongoose.disconnect();
  process.exit(0);
};

run().catch((err) => {
  console.error(err);
  process.exit(1);
});
