const jwt = require('jsonwebtoken');

/**
 * Generate a short-lived access token used to authenticate API requests.
 */
const generateAccessToken = (userId) => {
  return jwt.sign({ id: userId }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || '15m',
  });
};

/**
 * Generate a longer-lived refresh token used to obtain new access tokens
 * without forcing the user to log in again. Stored (hashed-free, simple demo)
 * on the user document so it can be revoked on logout.
 */
const generateRefreshToken = (userId) => {
  return jwt.sign({ id: userId }, process.env.JWT_REFRESH_SECRET, {
    expiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '7d',
  });
};

module.exports = { generateAccessToken, generateRefreshToken };
