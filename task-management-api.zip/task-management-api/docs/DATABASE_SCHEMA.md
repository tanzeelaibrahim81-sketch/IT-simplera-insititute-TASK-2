# Database Schema / ER Diagram

MongoDB with Mongoose. Two collections: **users** and **tasks**, related
1-to-many (one user has many tasks) via the `user` field on each task.

```
┌───────────────────────────────┐
│              User             │
├───────────────────────────────┤
│ _id            ObjectId (PK)  │
│ name           String         │
│ email          String (uniq)  │
│ password       String (hash)  │
│ avatar         String | null  │
│ refreshTokens  [ { token,     │
│                    createdAt }]│
│ activityLog    [ { action,    │
│                    details,   │
│                    timestamp }]│
│ isActive       Boolean        │
│ createdAt      Date           │
│ updatedAt      Date           │
└───────────────┬───────────────┘
                │ 1
                │
                │ owns
                │
                │ *
┌───────────────▼───────────────┐
│              Task              │
├────────────────────────────────┤
│ _id            ObjectId (PK)   │
│ user           ObjectId (FK)   │──▶ references User._id
│ title          String          │
│ description    String          │
│ priority       enum: low |     │
│                 medium | high  │
│ status         enum: pending | │
│                 in-progress |  │
│                 completed      │
│ dueDate        Date | null     │
│ isDeleted      Boolean         │
│ deletedAt      Date | null     │
│ createdAt      Date            │
│ updatedAt      Date            │
└────────────────────────────────┘
```

## Relationship

- **User (1) → Task (many)**: each task stores a `user` field (ObjectId
  reference to the owning user). Every task query in the API is scoped with
  `{ user: req.user.id }`, so a user can only ever see or modify their own
  tasks — this is enforced at the query level, not just the UI.

## Indexes

| Collection | Index | Purpose |
|---|---|---|
| users | `email` (unique) | Fast lookup on login, prevents duplicate accounts |
| tasks | `{ user: 1, status: 1 }` | Speeds up "my tasks with status X" queries |
| tasks | `{ user: 1, priority: 1 }` | Speeds up "my tasks with priority X" queries |
| tasks | `{ title: 'text', description: 'text' }` | Backs the search feature |

## Notes on design choices

- **Password hashing**: bcrypt with a cost factor of 12, done automatically
  in a Mongoose `pre('save')` hook so it's impossible to accidentally save a
  plaintext password.
- **Refresh tokens**: stored per-user as an array so a user can be logged in
  on multiple devices, and a single logout only revokes that device's token.
- **Soft delete**: tasks are flagged `isDeleted: true` rather than removed,
  so they can be restored and so "deleted" stats/history aren't lost. A
  `?hard=true` query param on the delete endpoint permanently removes a task
  if that's ever needed.
- **Activity log**: capped at the last 50 entries per user directly on the
  User document to avoid unbounded growth, which is fine at this scale;
  a production system with heavy activity would move this to its own
  collection.
