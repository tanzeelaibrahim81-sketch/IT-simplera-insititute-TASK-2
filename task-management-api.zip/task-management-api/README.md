# Secure Multi-User Task Management API

A production-ready backend built with **Node.js, Express, and MongoDB**,
featuring JWT authentication, bcrypt password hashing, and a fully
per-user-scoped Task Management REST API — built for the ITSimplera
Institute Full Stack Web Development Internship, Week 2 task.

---

## Features

### Core
- User registration, login, logout with **JWT access + refresh tokens**
- **bcrypt** password hashing (cost factor 12)
- Protected routes via JWT middleware
- Token expiration handling + `/api/auth/refresh-token` endpoint
- View/update profile, change password
- Full task CRUD, strictly scoped to the authenticated user

### Advanced (implements all 10, only 5 were required)
| Feature | How it works |
|---|---|
| Search | `?search=` full-text-style search across title & description |
| Filter by Status | `?status=pending\|in-progress\|completed` |
| Filter by Priority | `?priority=low\|medium\|high` |
| Pagination | `?page=&limit=` with a `pagination` object in the response |
| Sorting | `?sortBy=&order=asc\|desc` |
| Dashboard Statistics | `GET /api/tasks/stats/dashboard` |
| Soft Delete | `DELETE /api/tasks/:id` flags instead of removing; `PUT /api/tasks/:id/restore` undoes it |
| Recent Activity Log | `GET /api/users/activity` — tracks logins, task changes, etc. |
| Profile Picture Upload | `POST /api/users/profile/avatar` (multer, 2MB limit, image types only) |
| Task Completion Percentage | included in the dashboard stats response |

### Security
- bcrypt password hashing
- JWT auth middleware on all protected routes
- Secrets in `.env` (never committed — see `.env.example`)
- Centralized error handling (`src/middleware/errorHandler.js`)
- Request validation on every input-accepting route (`express-validator`)
- `helmet` for secure HTTP headers
- Rate limiting (general + a stricter limiter on auth routes)
- Refresh tokens stored per-user and revoked on logout / password change

---

## Tech Stack

Node.js · Express.js · MongoDB · Mongoose · JWT · bcrypt · multer ·
express-validator · helmet · express-rate-limit

---

## Project Structure

```
task-management-api/
├── server.js                  # Entry point
├── src/
│   ├── app.js                 # Express app setup (middleware, routes)
│   ├── config/
│   │   └── db.js              # MongoDB connection
│   ├── models/
│   │   ├── User.js
│   │   └── Task.js
│   ├── controllers/
│   │   ├── authController.js
│   │   ├── userController.js
│   │   └── taskController.js
│   ├── routes/
│   │   ├── authRoutes.js
│   │   ├── userRoutes.js
│   │   └── taskRoutes.js
│   ├── middleware/
│   │   ├── auth.js            # JWT protect middleware
│   │   ├── errorHandler.js    # Centralized error handling + AppError
│   │   ├── asyncHandler.js
│   │   ├── validators.js      # express-validator rule sets
│   │   ├── upload.js          # multer avatar upload config
│   │   └── rateLimiter.js
│   ├── utils/
│   │   ├── generateToken.js
│   │   └── seed.js            # optional demo data seeder
│   └── uploads/avatars/       # uploaded profile pictures (gitignored)
├── docs/
│   └── DATABASE_SCHEMA.md     # ER diagram + schema notes
├── postman_collection.json    # Import into Postman to try every endpoint
├── .env.example
└── package.json
```

---

## Getting Started

### 1. Prerequisites
- [Node.js](https://nodejs.org) v18+
- [MongoDB Community Server](https://www.mongodb.com/try/download/community)
  running locally, or a free [MongoDB Atlas](https://www.mongodb.com/atlas)
  cluster
- [Postman](https://www.postman.com/downloads) (optional, for testing)

### 2. Install
```bash
git clone <your-repo-url>
cd task-management-api
npm install
```

### 3. Configure environment
```bash
cp .env.example .env
```
Then edit `.env` and set at minimum:
- `MONGO_URI` — your MongoDB connection string
- `JWT_SECRET` / `JWT_REFRESH_SECRET` — long random strings
  (e.g. generate one with `node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"`)

### 4. Run
```bash
npm run dev      # development, with nodemon auto-reload
npm start        # production
```
The API will be available at `http://localhost:5000/api`.

### 5. (Optional) Seed demo data
```bash
npm run seed
```
Creates a demo user (`demo@example.com` / `password123`) with sample tasks
so you can immediately explore the dashboard stats endpoint.

### 6. Try it
Import `postman_collection.json` into Postman. Run **Register** or
**Login** first — the collection automatically stores the returned access
token in a variable and reuses it in every subsequent request.

---

## API Endpoints

### Auth — `/api/auth`
| Method | Endpoint | Access | Description |
|---|---|---|---|
| POST | `/register` | Public | Create a new account |
| POST | `/login` | Public | Log in, returns access token + sets refresh token cookie |
| POST | `/logout` | Private | Revokes the current refresh token |
| POST | `/refresh-token` | Public* | Exchanges a valid refresh token for a new access token |

### Users — `/api/users`
| Method | Endpoint | Access | Description |
|---|---|---|---|
| GET | `/profile` | Private | Get your profile |
| PUT | `/profile` | Private | Update name/email |
| PUT | `/change-password` | Private | Change password (revokes all sessions) |
| POST | `/profile/avatar` | Private | Upload a profile picture (`multipart/form-data`, field name `avatar`) |
| GET | `/activity` | Private | Recent activity log |

### Tasks — `/api/tasks`
| Method | Endpoint | Access | Description |
|---|---|---|---|
| POST | `/` | Private | Create a task |
| GET | `/` | Private | List your tasks — supports `search`, `status`, `priority`, `page`, `limit`, `sortBy`, `order` |
| GET | `/:id` | Private | Get one task |
| PUT | `/:id` | Private | Update a task |
| DELETE | `/:id` | Private | Soft delete (add `?hard=true` to permanently delete) |
| PUT | `/:id/restore` | Private | Restore a soft-deleted task |
| GET | `/stats/dashboard` | Private | Task counts by status/priority, completion %, overdue count |

**Private** routes require the header: `Authorization: Bearer <accessToken>`

### Example: create a task
```bash
curl -X POST http://localhost:5000/api/tasks \
  -H "Authorization: Bearer <accessToken>" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Finish the internship task",
    "description": "Build the secure task management API",
    "priority": "high",
    "status": "in-progress",
    "dueDate": "2026-07-20"
  }'
```

### Example: search + filter + paginate + sort
```bash
curl "http://localhost:5000/api/tasks?search=api&status=in-progress&priority=high&page=1&limit=10&sortBy=dueDate&order=asc" \
  -H "Authorization: Bearer <accessToken>"
```

---

## Database Schema

See [`docs/DATABASE_SCHEMA.md`](docs/DATABASE_SCHEMA.md) for the full ER
diagram and field-by-field breakdown of the `User` and `Task` collections.

---

## Deliverables Checklist (per task brief)

- [x] Public GitHub Repository — push this project and make it public
- [x] Complete Source Code — this repo
- [x] README.md — this file
- [x] Postman Collection — `postman_collection.json`
- [x] Database Schema / ER Diagram — `docs/DATABASE_SCHEMA.md`
- [ ] 5 Minute Demonstration Video — record a walkthrough (register → login →
      create/search/filter/paginate tasks → dashboard stats → soft
      delete/restore → avatar upload → logout)

---

## License

MIT
